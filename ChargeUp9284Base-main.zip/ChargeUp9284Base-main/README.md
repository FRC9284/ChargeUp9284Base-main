# Everybot 2023


Check back soon for some more notes here about why this code is the way it is.


FAQ:

Q: why isn't this using command based programming?\
A: the robot is simple enough to not need it, this is easier for a complete novice to read

Q: why isn't there PID on the arm?\
A: 254 once told me to use the simplest thing that works, and I think that is good advice.
